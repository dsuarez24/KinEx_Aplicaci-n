

package modelo;


public class MetodoDePago {
    private int codigoMetodoDePago ;
    private String descripcion  ;

    public MetodoDePago() {
    }

    public MetodoDePago(int codigoMetodoDePago, String descripcion) {
        this.codigoMetodoDePago = codigoMetodoDePago;
        this.descripcion = descripcion;
    }

    public int getCodigoMetodoDePago() {
        return codigoMetodoDePago;
    }

    public void setCodigoMetodoDePago(int codigoMetodoDePago) {
        this.codigoMetodoDePago = codigoMetodoDePago;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    
}
