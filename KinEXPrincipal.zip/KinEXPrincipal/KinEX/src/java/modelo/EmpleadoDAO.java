package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmpleadoDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    //CRUD
    
    //Método LISTAR
    public List listar(){
        String sql = "Select * from empleados";
        List <Empleado> listaEmpleado = new ArrayList<>();
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Empleado em = new Empleado();
                em.setCodigoEmpleado(rs.getInt(1));
                em.setCarnetEmpleado(rs.getInt(2));
                em.setApellidoEmpleado(rs.getString(3));
                em.setNombresEmpleado(rs.getString(4));
                em.setDireccionEmpleado(rs.getString(5));
                em.setTelefonoContacto(rs.getString(6));
                em.setCodigoTipoEmpleado(rs.getInt(7));
                listaEmpleado.add(em);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        
        return listaEmpleado;
    }
    
    //Método AGREGAR
    public int agregar(Empleado emp){
        String sql= "Insert into Empleados (carnetEmpleado, apellidoEmpleado, nombresEmpleado, direccionEmpleado, telefonoContacto, codigoTipoEmpleado) values (?,?,?,?,?,?)";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, emp.getCarnetEmpleado());
            ps.setString(2, emp.getApellidoEmpleado());
            ps.setString(3, emp.getNombresEmpleado());
            ps.setString(4, emp.getDireccionEmpleado());
            ps.setString(5, emp.getTelefonoContacto());
            ps.setInt(6, emp.getCodigoTipoEmpleado());
            ps.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("No se pudo agregar el registro ;(");
        }
        return resp;
    }
    
    //Método BUSCAR (por código)
    public Empleado listarCodigoEmpleado(int id){
        Empleado emp = new Empleado();
        String sql = "select * from Empleados where codigoEmpleado ="+ id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery(sql);
            while(rs.next()){
                emp.setCarnetEmpleado(rs.getInt(2));
                emp.setApellidoEmpleado(rs.getString(3));
                emp.setNombresEmpleado(rs.getString(4));
                emp.setDireccionEmpleado(rs.getString(5));
                emp.setTelefonoContacto(rs.getString(6));
                emp.setCodigoTipoEmpleado(rs.getInt(7));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return emp;
    }
    
    // Metodo de Editar
    public int actualizar(Empleado emp){
        String sql = "update Empleados set carnetEmpleado = ?, apellidoEmpleado = ?, nombresEmpleado = ?, direccionEmpleado = ?, telefonoContacto = ?, codigoTipoEmpleado = ? where codigoEmpleado = ?";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, emp.getCarnetEmpleado());
            ps.setString(2, emp.getApellidoEmpleado());
            ps.setString(3, emp.getNombresEmpleado());
            ps.setString(4, emp.getDireccionEmpleado());
            ps.setString(5, emp.getTelefonoContacto());
            ps.setInt(6, emp.getCodigoTipoEmpleado());
            ps.setInt(7, emp.getCodigoEmpleado());
            ps.executeUpdate();        
        }   catch (Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    // Metodo Eliminar
    public void eliminar(int id){
        String sql = "delete from Empleados where codigoEmpleado ="+id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
