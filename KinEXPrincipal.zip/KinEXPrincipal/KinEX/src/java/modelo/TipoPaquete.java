/*
Omar Emilaini Sánchez Mendoza
2019490
4:00 PM
7/21/2023
*/


package modelo;


public class TipoPaquete {
    private int codigoTipoPaquete;
    private String descripcionTipoPaquete;

    public TipoPaquete() {
    }
    
    public TipoPaquete(int codigoTipoPaquete, String descripcionTipoPaquete) {
        this.codigoTipoPaquete = codigoTipoPaquete;
        this.descripcionTipoPaquete = descripcionTipoPaquete;
    }

    public int getCodigoTipoPaquete() {
        return codigoTipoPaquete;
    }

    public void setCodigoTipoPaquete(int codigoTipoPaquete) {
        this.codigoTipoPaquete = codigoTipoPaquete;
    }

    public String getDescripcionTipoPaquete() {
        return descripcionTipoPaquete;
    }

    public void setDescripcionTipoPaquete(String descripcionTipoPaquete) {
        this.descripcionTipoPaquete = descripcionTipoPaquete;
    }
    
    
}
