package modelo;
public class Paquete {
    
    private int codigoPaquete;
    private String tamañoPaquete;
    private String pesoPaquete;
    private String contenido;
    private int codigoTipoPquete;

    public Paquete() {
    }

    public Paquete(int codigoPaquete, String tamañoPaquete, String pesoPaquete, String contenido, int codigoTipoPquete) {
        this.codigoPaquete = codigoPaquete;
        this.tamañoPaquete = tamañoPaquete;
        this.pesoPaquete = pesoPaquete;
        this.contenido = contenido;
        this.codigoTipoPquete = codigoTipoPquete;
    }

    public int getCodigoPaquete() {
        return codigoPaquete;
    }

    public void setCodigoPaquete(int codigoPaquete) {
        this.codigoPaquete = codigoPaquete;
    }

    public String getTamañoPaquete() {
        return tamañoPaquete;
    }

    public void setTamañoPaquete(String tamañoPaquete) {
        this.tamañoPaquete = tamañoPaquete;
    }

    public String getPesoPaquete() {
        return pesoPaquete;
    }

    public void setPesoPaquete(String pesoPaquete) {
        this.pesoPaquete = pesoPaquete;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public int getCodigoTipoPquete() {
        return codigoTipoPquete;
    }

    public void setCodigoTipoPquete(int codigoTipoPquete) {
        this.codigoTipoPquete = codigoTipoPquete;
    }
    
    
}
