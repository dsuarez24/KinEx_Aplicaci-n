package modelo;
public class Cliente {
    
    private int codigoCliente;
    private String apellidosCliente;
    private String nombresCliente;
    private String direccionCliente;
    private String telefonoCliente;
    private int codigoTipoCliente;
    private int codigoMetodoDePago;

    public Cliente() {
    }

    public Cliente(int codigoCliente, String apellidosCliente, String nombresCliente, String direccionCliente, String telefonoCliente, int codigoTipoCliente, int codigoMetodoDePago) {
        this.codigoCliente = codigoCliente;
        this.apellidosCliente = apellidosCliente;
        this.nombresCliente = nombresCliente;
        this.direccionCliente = direccionCliente;
        this.telefonoCliente = telefonoCliente;
        this.codigoTipoCliente = codigoTipoCliente;
        this.codigoMetodoDePago = codigoMetodoDePago;
    }

    public int getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(int codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public String getApellidosCliente() {
        return apellidosCliente;
    }

    public void setApellidosCliente(String apellidosCliente) {
        this.apellidosCliente = apellidosCliente;
    }

    public String getNombresCliente() {
        return nombresCliente;
    }

    public void setNombresCliente(String nombresCliente) {
        this.nombresCliente = nombresCliente;
    }

    public String getDireccionCliente() {
        return direccionCliente;
    }

    public void setDireccionCliente(String direccionCliente) {
        this.direccionCliente = direccionCliente;
    }

    public String getTelefonoCliente() {
        return telefonoCliente;
    }

    public void setTelefonoCliente(String telefonoCliente) {
        this.telefonoCliente = telefonoCliente;
    }

    public int getCodigoTipoCliente() {
        return codigoTipoCliente;
    }

    public void setCodigoTipoCliente(int codigoTipoCliente) {
        this.codigoTipoCliente = codigoTipoCliente;
    }

    public int getCodigoMetodoDePago() {
        return codigoMetodoDePago;
    }

    public void setCodigoMetodoDePago(int codigoMetodoDePago) {
        this.codigoMetodoDePago = codigoMetodoDePago;
    }
    
    
}
    
