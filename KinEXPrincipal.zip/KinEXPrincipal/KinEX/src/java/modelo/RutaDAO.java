
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class RutaDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    public List listar(){
        String sql = "Select * from Ruta";
        List<Ruta> listaRuta = new ArrayList<>();
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Ruta ru = new Ruta();
                ru.setCodigoRuta(rs.getInt(1));
                ru.setDistancia(rs.getString(2));
                ru.setMedioDeTransporte(rs.getString(3));
                ru.setEstadoRuta(rs.getString(4));
                listaRuta.add(ru);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaRuta;
    }
    
    public int agregar (Ruta ru){
        String sql = "insert into Ruta (codigoRuta,distancia, medioDeTransporte, estadoRuta) values (?,?,?,?)";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, ru.getCodigoRuta());
            ps.setString(2, ru.getDistancia());
            ps.setString(3, ru.getMedioDeTransporte());
            ps.setString(4, ru.getEstadoRuta());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("No se puedo agregar la Ruta");
        }
        
        return resp;
    }
    
    public Ruta listarCodigoRuta (int id){
        Ruta ru = new Ruta();
        String sql = "select * from ruta where codigoRuta = "+ id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                ru.setCodigoRuta(rs.getInt(1));
                ru.setDistancia(rs.getString(2));
                ru.setMedioDeTransporte(rs.getString(3));
                ru.setEstadoRuta(rs.getString(4));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ru;
    }
    
    public int actualizar (Ruta ru){
        String sql = "update ruta set distancia = ?, medioDeTransporte = ?, estadoRuta = ? where codigoRuta = ?";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, ru.getDistancia());
            ps.setString(2, ru.getMedioDeTransporte());
            ps.setString(3, ru.getEstadoRuta());
            ps.setInt(4, ru.getCodigoRuta());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return resp;
    }
    
    public void eliminar(int id){
        String sql = "delete from ruta where codigoRuta = " + id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
