/*
Omar Emilaini Sánchez Mendoza
2019490
4:00 PM
7/21/2023
*/
package modelo;


public class Ruta {
    private int codigoRuta;
    private String distancia;
    private String medioDeTransporte;
    private String estadoRuta;

    public Ruta() {
    }

    public Ruta(int codigoRuta, String distancia, String medioDeTransporte, String estadoRuta) {
        this.codigoRuta = codigoRuta;
        this.distancia = distancia;
        this.medioDeTransporte = medioDeTransporte;
        this.estadoRuta = estadoRuta;
    }

    public int getCodigoRuta() {
        return codigoRuta;
    }

    public void setCodigoRuta(int codigoRuta) {
        this.codigoRuta = codigoRuta;
    }

    public String getDistancia() {
        return distancia;
    }

    public void setDistancia(String distancia) {
        this.distancia = distancia;
    }

    public String getMedioDeTransporte() {
        return medioDeTransporte;
    }

    public void setMedioDeTransporte(String medioDeTransporte) {
        this.medioDeTransporte = medioDeTransporte;
    }

    public String getEstadoRuta() {
        return estadoRuta;
    }

    public void setEstadoRuta(String estadoRuta) {
        this.estadoRuta = estadoRuta;
    }
    
    
    
}
