
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class UsuarioDAO {
   
    Conexion cn = new Conexion ();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public Usuario Validar (String usuarioLogin, String contrasena){
    
    Usuario usuario = new Usuario ();
    String sql = "select * from Usuario where  usuarioLogin = ? and contrasena = ?";
    try{
        con = cn.Conexion();
        ps = con.prepareStatement(sql);
        ps.setString(1,usuarioLogin);
        ps.setString(2,contrasena);
        rs = ps.executeQuery();
        while(rs.next()){
        usuario.setCodigoUsuario(rs.getInt("codigoUsuario"));
        usuario.setNombreUsuario(rs.getString("nombreUsuario"));
        usuario.setApellidoUsuario(rs.getString("apellidoUsuario"));
        usuario.setUsuarioLogin(rs.getString("usuarioLogin"));
        usuario.setContrasena(rs.getString("contrasena"));
        }
        
    }catch(Exception e){
    e.printStackTrace();
    }

    return usuario;
    }
}
