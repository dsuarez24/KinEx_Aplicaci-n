package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    public List listar() {
        String sql = "select * from producto";
        List<Producto> listaProducto = new ArrayList<>();
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Producto pr = new Producto();
                pr.setCodigoProducto(rs.getInt(1));
                pr.setNombreProducto(rs.getString(2));
                pr.setCantidad(rs.getInt(3));
                pr.setPrecio(rs.getString(4));
                pr.setCodigoTipoProducto(rs.getInt(5));
                listaProducto.add(pr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaProducto;
    }
    
    public int agregar(Producto pr) {
        String sql = "Insert into Producto (codigoProducto, nombreProducto, cantidad, precio, codigoTipoProducto) values(?,?,?,?,?)";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, pr.getCodigoProducto());
            ps.setString(2, pr.getNombreProducto());
            ps.setInt(3, pr.getCantidad());
            ps.setString(4, pr.getPrecio());
            ps.setInt(5, pr.getCodigoTipoProducto());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resp;
    }
    
    public Producto listarPorCodigoProducto(int id) {
        Producto pr = new Producto();
        String sql = "select * from Producto where codigoProducto ="+id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                pr.setNombreProducto(rs.getString(2));
                pr.setCantidad(rs.getInt(3));
                pr.setPrecio(rs.getString(4));
                pr.setCodigoTipoProducto(rs.getInt(5));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pr;
    }
    
    //actualizar
    public int actualizar(Producto pd){
        String sql = "update producto set nombreProducto = ?, cantidad = ?, precio = ?, codigoTipoProducto = ? where codigoProducto = ?";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, pd.getNombreProducto());
            ps.setInt(2, pd.getCantidad());
            ps.setString(3, pd.getPrecio());
            ps.setInt(4, pd.getCodigoTipoProducto());
            ps.setInt(5, pd.getCodigoProducto());
            ps.executeUpdate();        
        }   catch (Exception e){
            e.printStackTrace();
        }
        return resp;
    }

    //eliminar
    public void eliminar(int id){
        String sql = "delete from producto where codigoProducto ="+id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
