package modelo;

public class Empleado {
    private int codigoEmpleado;
    private int carnetEmpleado;
    private String apellidoEmpleado;
    private String nombresEmpleado;
    private String direccionEmpleado;
    private String telefonoContacto;
    private int codigoTipoEmpleado;

    public Empleado() {
    }

    public Empleado(int codigoEmpleado, int carnetEmpleado, String apellidoEmpleado, String nombresEmpleado, String direccionEmpleado, String telefonoContacto, int codigoTipoEmpleado) {
        this.codigoEmpleado = codigoEmpleado;
        this.carnetEmpleado = carnetEmpleado;
        this.apellidoEmpleado = apellidoEmpleado;
        this.nombresEmpleado = nombresEmpleado;
        this.direccionEmpleado = direccionEmpleado;
        this.telefonoContacto = telefonoContacto;
        this.codigoTipoEmpleado = codigoTipoEmpleado;
    }

    public int getCodigoEmpleado() {
        return codigoEmpleado;
    }

    public void setCodigoEmpleado(int codigoEmpleado) {
        this.codigoEmpleado = codigoEmpleado;
    }

    public int getCarnetEmpleado() {
        return carnetEmpleado;
    }

    public void setCarnetEmpleado(int carnetEmpleado) {
        this.carnetEmpleado = carnetEmpleado;
    }

    public String getApellidoEmpleado() {
        return apellidoEmpleado;
    }

    public void setApellidoEmpleado(String apellidoEmpleado) {
        this.apellidoEmpleado = apellidoEmpleado;
    }

    public String getNombresEmpleado() {
        return nombresEmpleado;
    }

    public void setNombresEmpleado(String nombresEmpleado) {
        this.nombresEmpleado = nombresEmpleado;
    }

    public String getDireccionEmpleado() {
        return direccionEmpleado;
    }

    public void setDireccionEmpleado(String direccionEmpleado) {
        this.direccionEmpleado = direccionEmpleado;
    }

    public String getTelefonoContacto() {
        return telefonoContacto;
    }

    public void setTelefonoContacto(String telefonoContacto) {
        this.telefonoContacto = telefonoContacto;
    }

    public int getCodigoTipoEmpleado() {
        return codigoTipoEmpleado;
    }

    public void setCodigoTipoEmpleado(int codigoTipoEmpleado) {
        this.codigoTipoEmpleado = codigoTipoEmpleado;
    }
    
}
