package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
 
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    public List listar(){
        
        String sql = "Select * from cliente";
        List<Cliente> listaCliente = new ArrayList<>();
        try{
            
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                
                Cliente cli = new Cliente();
                cli.setCodigoCliente(rs.getInt(1));
                cli.setApellidosCliente(rs.getString(2));
                cli.setNombresCliente(rs.getString(3));
                cli.setDireccionCliente(rs.getString(4));
                cli.setTelefonoCliente(rs.getString(5));
                cli.setCodigoTipoCliente(rs.getInt(6));
                cli.setCodigoMetodoDePago(rs.getInt(7));
                listaCliente.add(cli);
            }
        }catch(Exception e){
            
            e.printStackTrace();
        }
        
        return listaCliente;
    }
    
    public int agregar(Cliente cli){
        
        String sql = "insert into Cliente(apellidosCliente, nombresCliente, direccionCliente, telefonoCliente, codigoTipoCliente, codigoMetodoDePago) values(?,?,?,?,?,?)";
        try{
            
            con =cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, cli.getApellidosCliente());
            ps.setString(2, cli.getNombresCliente());
            ps.setString(3, cli.getDireccionCliente());
            ps.setString(4, cli.getTelefonoCliente());
            ps.setInt(5, cli.getCodigoTipoCliente());
            ps.setInt(6, cli.getCodigoMetodoDePago());
            ps.executeUpdate();
        }catch(Exception e){
            
            e.printStackTrace();
        }
        
        return resp;
    }
    
    public Cliente listarCodigoCliente(int id){
        
        Cliente cli = new Cliente();
        String sql = "select * from Cliente where codigoCliente = " + id;
        try{
            
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery(sql);
            while(rs.next()){
                
                cli.setApellidosCliente(rs.getString(2));
                cli.setNombresCliente(rs.getString(3));
                cli.setDireccionCliente(rs.getString(4));
                cli.setTelefonoCliente(rs.getString(5));
                cli.setCodigoTipoCliente(rs.getInt(6));
                cli.setCodigoMetodoDePago(rs.getInt(7));
            }
        }catch(Exception e){
            
            e.printStackTrace();
        }
        
        return cli;
    }
    
    public int actualizar(Cliente cli){
        
        String sql = "update Cliente set apellidosCliente = ?, nombresCliente = ?, direccionCliente = ?, telefonoCliente = ?, codigoTipoCliente = ? codigoMetodoDePago = ? where codigoCliente = ?";
        try{
            
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, cli.getApellidosCliente());
            ps.setString(2, cli.getNombresCliente());
            ps.setString(3, cli.getDireccionCliente());
            ps.setString(4, cli.getTelefonoCliente());
            ps.setInt(5, cli.getCodigoTipoCliente());
            ps.setInt(6, cli.getCodigoMetodoDePago());
            ps.setInt(7, cli.getCodigoCliente());
            ps.executeUpdate();
        }catch(Exception e){
            
            e.printStackTrace();
        } 
        
        return resp;
    }
    
    public void eliminar(int id){
        
        String sql = "delete from Cliente where codigoCliente = " + id;
        try{
            
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            
            e.printStackTrace();
        }
    }
    
    
}
