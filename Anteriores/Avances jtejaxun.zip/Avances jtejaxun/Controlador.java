/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.ClienteDAO;
import modelo.Empleado;
import modelo.EmpleadoDAO;
import modelo.Producto;
import modelo.ProductoDAO;
import modelo.Ruta;
import modelo.RutaDAO;
import modelo.Usuario;
import modelo.UsuarioDAO;

/**
 *
 * @author informatica
 */
public class Controlador extends HttpServlet {

    Usuario usuario = new Usuario();
    UsuarioDAO usuarioDAO = new UsuarioDAO();
    Empleado empleado = new Empleado();
    EmpleadoDAO empleadoDAO = new EmpleadoDAO();
    Ruta ruta = new Ruta();
    RutaDAO rutaDAO = new RutaDAO();
    Producto producto = new Producto();
    ProductoDAO productoDAO = new ProductoDAO();
    ClienteDAO clienteDAO = new ClienteDAO();
    int codCliente;
    int codUsuario;
    int codRuta;
    int codEmpleado;
    int codProducto;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");
        if (menu.equals("Principal")) {
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
        } else if (menu.equals("Usuario")) {
            switch (accion) {
                case "listar":
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
            }
            request.getRequestDispatcher("Usuario.jsp").forward(request, response);

        } else if (menu.equals("Cliente")) {
            switch (accion) {
                case "listar":
                    List listaCliente= clienteDAO.listar();
                    request.setAttribute("clientes", listaCliente);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
            }
            request.getRequestDispatcher("Cliente.jsp").forward(request, response);
        } else if (menu.equals("Empleado")) {
            switch (accion) {
                case "listar":
                    List listaEmpleado = empleadoDAO.listar();
                    request.setAttribute("empleados", listaEmpleado);
                    break;
                case "Agregar":
                    int carnetEmpleado = Integer.parseInt(request.getParameter("txtCarnetEmpleado"));
                    String apellidoEmpleado = request.getParameter("txtApellidoEmpleado");
                    String nombresEmpleado = request.getParameter("txtNombresEmpleado");
                    String direccionEmpleado = request.getParameter("txtDireccionEmpleado");
                    String telefonoContacto = request.getParameter("txtTelefonoContacto");
                    int codigoTipoEmpleado = Integer.parseInt(request.getParameter("txtCodigoTipoEmpleado"));
                    empleado.setCarnetEmpleado(carnetEmpleado);
                    empleado.setApellidoEmpleado(apellidoEmpleado);
                    empleado.setNombresEmpleado(nombresEmpleado);
                    empleado.setDireccionEmpleado(direccionEmpleado);
                    empleado.setTelefonoContacto(telefonoContacto);
                    empleado.setCodigoTipoEmpleado(codigoTipoEmpleado);
                    empleadoDAO.agregar(empleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=listar").forward(request, response);
                    break;
                case "Editar":
                    codEmpleado = Integer.parseInt(request.getParameter("codigoEmpleado"));
                    Empleado e = empleadoDAO.listarCodigoEmpleado(codEmpleado);
                    request.setAttribute("empleado", e);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=listar").forward(request, response);
                    break;
                case "Actualizar":
                    carnetEmpleado = Integer.parseInt(request.getParameter("txtCarnetEmpleado"));
                    apellidoEmpleado = request.getParameter("txtApellidoEmpleado");
                    nombresEmpleado = request.getParameter("txtNombresEmpleado");
                    direccionEmpleado = request.getParameter("txtDireccionEmpleado");
                    telefonoContacto = request.getParameter("txtTelefonoContacto");
                    codigoTipoEmpleado = Integer.parseInt(request.getParameter("txtCodigoTipoEmpleado"));
                    empleado.setCarnetEmpleado(carnetEmpleado);
                    empleado.setApellidoEmpleado(apellidoEmpleado);
                    empleado.setNombresEmpleado(nombresEmpleado);
                    empleado.setDireccionEmpleado(direccionEmpleado);
                    empleado.setTelefonoContacto(telefonoContacto);
                    empleado.setCodigoTipoEmpleado(codigoTipoEmpleado);
                    empleado.setCodigoEmpleado(codEmpleado);
                    empleadoDAO.actualizar(empleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=listar").forward(request, response);
                    break;
                case "Eliminar":
                    int codEmpleado = Integer.parseInt(request.getParameter("codigoEmpleado"));
                    empleadoDAO.eliminar(codEmpleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("Empleados.jsp").forward(request, response);
        } else if (menu.equals("Empresas")) {
            request.getRequestDispatcher("Empresas.jsp").forward(request, response);
        } else if (menu.equals("Home")) {
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
        } else if (menu.equals("MetodoDePago")) {
            request.getRequestDispatcher("MetodoDePago.jsp").forward(request, response);
        } else if (menu.equals("Paquete")) {
            request.getRequestDispatcher("Paquete.jsp").forward(request, response);
        } else if (menu.equals("Producto")) {
            switch (accion) {
                case "listar":
                    List listaProducto = productoDAO.listar();
                    request.setAttribute("productos", listaProducto);
                    break;
                case "Agregar":
                    String nombreProducto = request.getParameter("txtNombreProducto");
                    int cantidad = Integer.parseInt(request.getParameter("txtCantidad"));
                    String precio = request.getParameter("txtPrecio");
                    int codigoTipoProducto = Integer.parseInt(request.getParameter("txtCodigoTipoProducto"));
                    producto.setNombreProducto(nombreProducto);
                    producto.setCantidad(cantidad);
                    producto.setPrecio(precio);
                    producto.setCodigoTipoProducto(codigoTipoProducto);
                    productoDAO.agregar(producto);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=listar").forward(request, response);
                    break;
                case "Editar":
                    codProducto = Integer.parseInt(request.getParameter("codigoProducto"));
                    Producto pro = productoDAO.listarPorCodigoProducto(codProducto);
                    request.setAttribute("producto", pro);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=listar").forward(request, response);
                    break;

                case "Actualizar":
                    nombreProducto = request.getParameter("txtNombreProducto");
                    cantidad = Integer.parseInt(request.getParameter("txtCantidad"));
                    precio = request.getParameter("txtPrecio");
                    codigoTipoProducto = Integer.parseInt(request.getParameter("txtCodigoTipoProducto"));
                    producto.setNombreProducto(nombreProducto);
                    producto.setCantidad(cantidad);
                    producto.setPrecio(precio);
                    producto.setCodigoTipoProducto(codigoTipoProducto);
                    producto.setCodigoProducto(codProducto);
                    productoDAO.actualizar(producto);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=listar").forward(request, response);
                    break;
                case "Eliminar":
                    int codProducto = Integer.parseInt(request.getParameter("codigoProducto"));
                    productoDAO.eliminar(codProducto);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("Productos.jsp").forward(request, response);
        } else if (menu.equals("Ruta")) {
            switch (accion) {
                case "listar":
                    List listaRuta = rutaDAO.listar();
                    request.setAttribute("rutas", listaRuta);
                    break;
                case "Agregar":
                    String codigo = request.getParameter("txtCodigoRuta");
                    String distancia = request.getParameter("txtDistancia");
                    String transporte = request.getParameter("txtTransporte");
                    String estado = request.getParameter("txtEstado");
                    ruta.setCodigoRuta(Integer.parseInt(codigo));
                    ruta.setDistancia(distancia);
                    ruta.setMedioDeTransporte(transporte);
                    ruta.setEstadoRuta(estado);
                    rutaDAO.agregar(ruta);
                    request.getRequestDispatcher("Controlador?menu=Ruta&accion=listar").forward(request, response);
                    break;
                case "Editar":
                    codRuta = Integer.parseInt(request.getParameter("codigoRuta"));
                    Ruta r = rutaDAO.listarCodigoRuta(codRuta);
                    request.setAttribute("ruta", r);
                    request.getRequestDispatcher("Controlador?menu=Ruta&accion=listar").forward(request, response);
                    break;
                case "Actualizar":
                    distancia = request.getParameter("txtDistancia");
                    transporte = request.getParameter("txtTransporte");
                    estado = request.getParameter("txtEstado");
                    ruta.setDistancia(distancia);
                    ruta.setMedioDeTransporte(transporte);
                    ruta.setEstadoRuta(estado);
                    ruta.setCodigoRuta(codRuta);
                    rutaDAO.actualizar(ruta);
                    request.getRequestDispatcher("Controlador?menu=Ruta&accion=listar").forward(request, response);
                    break;
                case "Eliminar":
                    codRuta = Integer.parseInt(request.getParameter("codigoRuta"));
                    rutaDAO.eliminar(codRuta);
                    request.getRequestDispatcher("Controlador?menu=Ruta&accion=listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("Ruta.jsp").forward(request, response);
        } else if (menu.equals("TipoEmpleado")) {
            request.getRequestDispatcher("TipoEmpleado.jsp").forward(request, response);
        } else if (menu.equals("TipoPaquete")) {
            request.getRequestDispatcher("TipoPaquete.jsp").forward(request, response);
        } else if (menu.equals("TipoProducto")) {
            request.getRequestDispatcher("TipoProducto.jsp").forward(request, response);
        } else if (menu.equals("TipoUbicacion")) {
            request.getRequestDispatcher("TipoUbicacion.jsp").forward(request, response);
        } else if (menu.equals("Ubicacion")) {
            request.getRequestDispatcher("Ubicacion.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
