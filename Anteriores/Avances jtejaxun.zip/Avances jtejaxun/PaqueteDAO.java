package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PaqueteDAO {
    
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    public List listar(){
        
        String sql = "select * from paquete";
        List<Paquete> listaPaquete = new ArrayList<>();
        try{
            
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                
                Paquete pa = new Paquete();
                pa.setTamañoPaquete(rs.getString(1));
                pa.setPesoPaquete(rs.getString(2));
                pa.setContenido(rs.getString(3));
                pa.setCodigoTipoPquete(rs.getInt(4));
                listaPaquete.add(pa);
            }
        }catch(Exception e){
            
            e.printStackTrace();
        }
        
        return listaPaquete;
    }
    
    public int agregar(Paquete pa){
        
        String sql = "insert into Paquete(tamañoPaquete, pesoPaquete, contenido, codigoTipoPaquete) values (?,?,?,?)";
        try{
            
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, pa.getTamañoPaquete());
            ps.setString(2, pa.getPesoPaquete());
            ps.setString(3, pa.getContenido());
            ps.setInt(4, pa.getCodigoTipoPquete());
            ps.executeUpdate();
        }catch(Exception e){
            
            e.printStackTrace();
        }
        
        return resp;
    }
    
    public Paquete listarCodigoPaquete(int id){
        
        Paquete pa = new Paquete();
        String sql = "select * from Paquete where codigoPaquete = " + id;
        try{
            
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery(sql);
            while(rs.next()){
                
                pa.setTamañoPaquete(rs.getString(2));
                pa.setPesoPaquete(rs.getString(3));
                pa.setContenido(rs.getString(4));
                pa.setCodigoTipoPquete(rs.getInt(5));
            }
        }catch(Exception e){
            
            e.printStackTrace();
        }
        
        return pa;
    }
    
    public int actualizar(Paquete pa){
        
        String sql = "update Paquete set tamañoPaquete = ?, pesoPaquete = ?, contenido = ?, codigoTipoPaquete = ? where codigoPaquete = ?";
        try{
            
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, pa.getTamañoPaquete());
            ps.setString(2, pa.getPesoPaquete());
            ps.setString(3, pa.getContenido());
            ps.setInt(4, pa.getCodigoTipoPquete());
            ps.setInt(5, pa.getCodigoPaquete());
            ps.executeUpdate();
        }catch(Exception e){
            
            e.printStackTrace();
        }
        
        return resp;
    }
    
    public void eliminar(int id){
        
        String sql = "delete from Paquete where codigoPaquete = " + id;
        try{
            
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            
            e.printStackTrace();
        }
    }
}
